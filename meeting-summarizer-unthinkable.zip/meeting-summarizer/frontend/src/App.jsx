import { useEffect, useState } from "react";
import "./App.css";
import Uploader from "./components/Uploader.jsx";
import Results from "./components/Results.jsx";
import WaveLoader from "./components/WaveLoader.jsx";
import { IconWave, IconSpark, IconAlert } from "./icons.jsx";

const MAX_BYTES = 25 * 1024 * 1024;

const STAGES = [
  "Uploading recording…",
  "Transcribing with Whisper…",
  "Pulling out decisions & action items…",
];

export default function App() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("idle"); // idle | loading | done | error
  const [stage, setStage] = useState(STAGES[0]);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [health, setHealth] = useState(null); // null | true | false

  // Check whether the backend has an API key configured.
  useEffect(() => {
    fetch("/api/health")
      .then((r) => r.json())
      .then((d) => setHealth(Boolean(d.configured)))
      .catch(() => setHealth(false));
  }, []);

  // Advance the loading stage labels while a request is in flight.
  useEffect(() => {
    if (status !== "loading") return;
    let i = 0;
    setStage(STAGES[0]);
    const id = setInterval(() => {
      i = Math.min(i + 1, STAGES.length - 1);
      setStage(STAGES[i]);
    }, 4000);
    return () => clearInterval(id);
  }, [status]);

  function selectFile(f) {
    setError("");
    if (f.size > MAX_BYTES) {
      setError("That file is over 25 MB. Whisper accepts recordings up to 25 MB.");
      return;
    }
    if (f.size === 0) {
      setError("That file looks empty. Please choose a valid recording.");
      return;
    }
    setFile(f);
  }

  function reset() {
    setFile(null);
    setResult(null);
    setStatus("idle");
    setError("");
  }

  async function summarize() {
    if (!file) return;
    setStatus("loading");
    setError("");
    setResult(null);

    const form = new FormData();
    form.append("file", file);

    try {
      const res = await fetch("/api/summarize", { method: "POST", body: form });

      if (!res.ok) {
        let detail = `Request failed (${res.status}).`;
        try {
          const body = await res.json();
          if (body?.detail) detail = body.detail;
        } catch {
          /* non-JSON error body — keep the generic message */
        }
        throw new Error(detail);
      }

      const data = await res.json();
      setResult(data);
      setStatus("done");
    } catch (err) {
      setError(
        err.message === "Failed to fetch"
          ? "Could not reach the server. Is the backend running on port 8000?"
          : err.message
      );
      setStatus("error");
    }
  }

  const loading = status === "loading";

  return (
    <div className="app">
      <header className="masthead">
        <div className="brand">
          <div className="brand__mark">
            <IconWave style={{ color: "#fff" }} />
          </div>
          <div>
            <div className="brand__title">Meeting Summarizer</div>
            <div className="brand__sub">audio → structured notes</div>
          </div>
        </div>
        <div className="masthead__status">
          <span
            className={
              health === null ? "dot" : health ? "dot dot--ok" : "dot dot--off"
            }
          />
          {health === null
            ? "Checking backend…"
            : health
            ? "Backend ready"
            : "API key not configured"}
        </div>
      </header>

      <section className="hero">
        <div className="hero__eyebrow">Whisper transcription · AI notes</div>
        <h1>
          Turn a recording into <em>clear, honest</em> meeting notes.
        </h1>
        <p>
          Upload your audio and get a concise summary, the decisions that were
          actually made, and action items with owners and deadlines. Nothing is
          invented — anything the meeting didn't state is marked{" "}
          <em>Not specified</em>.
        </p>
      </section>

      {!result && (
        <>
          <Uploader
            file={file}
            onSelect={selectFile}
            onClear={() => setFile(null)}
            disabled={loading}
          />

          {error && (
            <div className="banner" role="alert">
              <IconAlert />
              <div>
                <strong>Something went wrong.</strong> {error}
              </div>
            </div>
          )}

          {!loading && (
            <div className="actions">
              <button
                className="btn btn--primary"
                onClick={summarize}
                disabled={!file || health === false}
              >
                <IconSpark />
                Summarize meeting
              </button>
              {file && (
                <button className="btn btn--ghost" onClick={reset}>
                  Clear
                </button>
              )}
            </div>
          )}

          {loading && <WaveLoader stage={stage} />}
        </>
      )}

      {result && <Results data={result} onReset={reset} />}

      <footer className="footer">
        Built with FastAPI · Whisper · React — no data is stored after processing
      </footer>
    </div>
  );
}
