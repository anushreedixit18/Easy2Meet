import { useState } from "react";
import {
  IconSpark,
  IconGavel,
  IconTask,
  IconDoc,
  IconChevron,
  IconUser,
  IconClock,
} from "../icons.jsx";

/* Renders a value, styling the literal "Not specified" as muted/italic
   so the user can instantly see what the meeting did NOT state. */
function Value({ text }) {
  const muted = text === "Not specified";
  return (
    <span className={`tag__val${muted ? " tag__val--muted" : ""}`}>{text}</span>
  );
}

export default function Results({ data, onReset }) {
  const [showTranscript, setShowTranscript] = useState(false);
  const { summary, key_decisions, action_items, transcript } = data;

  return (
    <section className="results">
      <div className="results__bar">
        <h2 className="results__title">Meeting notes</h2>
        <button className="btn btn--ghost" onClick={onReset}>
          Summarize another
        </button>
      </div>

      {/* Summary */}
      <div className="card panel">
        <div className="panel__head">
          <div className="panel__icon panel__icon--summary">
            <IconSpark />
          </div>
          <div className="panel__label">Summary</div>
        </div>
        <p className="summary-text">{summary}</p>
      </div>

      {/* Key decisions */}
      <div className="card panel">
        <div className="panel__head">
          <div className="panel__icon panel__icon--decisions">
            <IconGavel />
          </div>
          <div className="panel__label">Key decisions</div>
          <div className="panel__count">{key_decisions.length}</div>
        </div>
        {key_decisions.length > 0 ? (
          <ul className="decisions">
            {key_decisions.map((d, i) => (
              <li key={i}>{d}</li>
            ))}
          </ul>
        ) : (
          <p className="empty">No explicit decisions were recorded.</p>
        )}
      </div>

      {/* Action items */}
      <div className="card panel">
        <div className="panel__head">
          <div className="panel__icon panel__icon--actions">
            <IconTask />
          </div>
          <div className="panel__label">Action items</div>
          <div className="panel__count">{action_items.length}</div>
        </div>
        {action_items.length > 0 ? (
          action_items.map((a, i) => (
            <div className="action" key={i}>
              <div className="action__task">{a.task}</div>
              <div className="action__meta">
                <span className="tag">
                  <IconUser style={{ width: 14, height: 14, color: "var(--ink-faint)" }} />
                  <span className="tag__key">Owner</span>
                  <Value text={a.owner} />
                </span>
                <span className="tag">
                  <IconClock style={{ width: 14, height: 14, color: "var(--ink-faint)" }} />
                  <span className="tag__key">Deadline</span>
                  <Value text={a.deadline} />
                </span>
              </div>
            </div>
          ))
        ) : (
          <p className="empty">No action items were assigned.</p>
        )}
      </div>

      {/* Transcript */}
      <div className="card panel">
        <div className="panel__head">
          <div className="panel__icon panel__icon--transcript">
            <IconDoc />
          </div>
          <div className="panel__label">Full transcript</div>
        </div>
        <button
          className="transcript__toggle"
          aria-expanded={showTranscript}
          onClick={() => setShowTranscript((v) => !v)}
        >
          {showTranscript ? "Hide transcript" : "Show transcript"}
          <IconChevron />
        </button>
        {showTranscript && <div className="transcript__body">{transcript}</div>}
      </div>
    </section>
  );
}
