import { useRef, useState } from "react";
import { IconUpload, IconAudio, IconClose } from "../icons.jsx";

const ACCEPT = ".mp3,.mp4,.mpeg,.mpga,.m4a,.wav,.webm,.ogg,.flac";

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Uploader({ file, onSelect, onClear, disabled }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);

  function handleDrop(e) {
    e.preventDefault();
    setDragging(false);
    if (disabled) return;
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) onSelect(dropped);
  }

  if (file) {
    return (
      <div className="card file">
        <div className="file__badge">
          <IconAudio />
        </div>
        <div className="file__meta">
          <div className="file__name">{file.name}</div>
          <div className="file__size">{formatSize(file.size)}</div>
        </div>
        {!disabled && (
          <button className="file__clear" onClick={onClear} aria-label="Remove file">
            <IconClose />
          </button>
        )}
      </div>
    );
  }

  return (
    <div
      className={`dropzone${dragging ? " dropzone--drag" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
    >
      <div className="dropzone__icon">
        <IconUpload />
      </div>
      <div className="dropzone__title">Drop a meeting recording here</div>
      <div className="dropzone__hint">or click to browse your files</div>
      <div className="dropzone__formats">MP3 · M4A · WAV · WEBM · OGG · FLAC — up to 25 MB</div>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT}
        disabled={disabled}
        onChange={(e) => {
          const chosen = e.target.files?.[0];
          if (chosen) onSelect(chosen);
          e.target.value = "";
        }}
        aria-label="Upload meeting audio"
      />
    </div>
  );
}
