/* Signature loading state: an animated audio waveform that ties the
   wait directly to the audio-transcription subject. */

export default function WaveLoader({ stage }) {
  return (
    <div className="card loader" role="status" aria-live="polite">
      <div className="wave" aria-hidden="true">
        {Array.from({ length: 9 }).map((_, i) => (
          <span key={i} />
        ))}
      </div>
      <div className="loader__stage">{stage}</div>
      <div className="loader__note">This can take up to a minute for longer recordings</div>
    </div>
  );
}
