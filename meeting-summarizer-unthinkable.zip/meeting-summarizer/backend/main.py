"""
Meeting Summarizer — FastAPI backend.

Flow:
  1. Receive an uploaded audio file.
  2. Transcribe it with OpenAI Whisper (speech-to-text).
  3. Send the transcript through a strongly-structured LLM prompt.
  4. Return a JSON payload: summary, key decisions, action items, full transcript.

The LLM is instructed to NEVER invent information. Any missing field
(owner, deadline, etc.) is returned as the literal string "Not specified".
"""

import json
import os
import pathlib
import tempfile

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from openai import OpenAI
from pydantic import BaseModel

HERE = pathlib.Path(__file__).resolve().parent

load_dotenv()

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TRANSCRIBE_MODEL = os.getenv("TRANSCRIBE_MODEL", "whisper-1")
SUMMARY_MODEL = os.getenv("SUMMARY_MODEL", "gpt-4o-mini")

# Comma-separated list of allowed frontend origins for CORS.
ALLOWED_ORIGINS = os.getenv(
    "ALLOWED_ORIGINS",
    "http://localhost:5173,http://127.0.0.1:5173,"
    "http://localhost:8000,http://127.0.0.1:8000",
).split(",")

# Reject uploads larger than this (Whisper's own hard limit is 25 MB).
MAX_UPLOAD_BYTES = 25 * 1024 * 1024

ALLOWED_EXTENSIONS = {
    ".mp3", ".mp4", ".mpeg", ".mpga", ".m4a", ".wav", ".webm", ".ogg", ".flac",
}

client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

app = FastAPI(title="Meeting Summarizer API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in ALLOWED_ORIGINS],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------
class ActionItem(BaseModel):
    task: str
    owner: str
    deadline: str


class SummaryResult(BaseModel):
    summary: str
    key_decisions: list[str]
    action_items: list[ActionItem]
    transcript: str


class TranscriptIn(BaseModel):
    transcript: str


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """\
You are a precise meeting-notes assistant. You are given the raw transcript of a
single meeting. Produce a faithful, structured summary of ONLY what the
transcript actually contains.

Hard rules — follow every one:
1. NEVER invent, assume, or infer information that is not present in the
   transcript. Do not guess owners, dates, numbers, or outcomes.
2. If a field is not explicitly stated in the transcript, use the exact string
   "Not specified". This applies to action-item owners and deadlines in
   particular.
3. A "key decision" is something the group explicitly agreed to, chose, or
   resolved. Do not list mere discussion points or open questions as decisions.
4. An "action item" is a concrete task someone is expected to do. Extract the
   owner only if a specific person/role is named for that task, and the deadline
   only if an explicit date or timeframe is stated for that task.
5. Keep the summary concise: 2–5 sentences capturing purpose and outcomes.
6. If the transcript is empty, unintelligible, or clearly not a meeting, return
   empty lists and a summary of "Not specified".

Return ONLY valid JSON matching exactly this schema (no markdown, no commentary):
{
  "summary": "string",
  "key_decisions": ["string", ...],
  "action_items": [
    {"task": "string", "owner": "string", "deadline": "string"}
  ]
}
"""


def _validate_upload(file: UploadFile, size: int) -> None:
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file type '{ext or 'unknown'}'. "
                f"Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
            ),
        )
    if size == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if size > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=400,
            detail="File too large. Whisper accepts audio up to 25 MB.",
        )


def _transcribe(path: str) -> str:
    with open(path, "rb") as audio:
        resp = client.audio.transcriptions.create(
            model=TRANSCRIBE_MODEL,
            file=audio,
            response_format="text",
        )
    # response_format="text" returns a plain string.
    return str(resp).strip()


def _summarize(transcript: str) -> dict:
    completion = client.chat.completions.create(
        model=SUMMARY_MODEL,
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Meeting transcript:\n\n{transcript}"},
        ],
    )
    raw = completion.choices[0].message.content or "{}"
    data = json.loads(raw)

    # Normalise / harden the shape so the frontend can trust it.
    summary = data.get("summary") or "Not specified"
    decisions = [d for d in data.get("key_decisions", []) if isinstance(d, str)]

    action_items = []
    for item in data.get("action_items", []):
        if not isinstance(item, dict):
            continue
        task = (item.get("task") or "").strip()
        if not task:
            continue
        action_items.append(
            {
                "task": task,
                "owner": (item.get("owner") or "Not specified").strip()
                or "Not specified",
                "deadline": (item.get("deadline") or "Not specified").strip()
                or "Not specified",
            }
        )

    return {
        "summary": summary,
        "key_decisions": decisions,
        "action_items": action_items,
    }


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/")
def index() -> FileResponse:
    """Serve the Easy2Meet single-file UI so the whole app runs from one server."""
    return FileResponse(HERE / "easy2meet.html")


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "configured": client is not None}


@app.post("/api/summarize-text", response_model=SummaryResult)
def summarize_text(payload: TranscriptIn) -> SummaryResult:
    """Summarize a transcript the user pasted — skips Whisper entirely."""
    if client is None:
        raise HTTPException(
            status_code=500,
            detail="Server is missing OPENAI_API_KEY. Set it in backend/.env.",
        )
    transcript = (payload.transcript or "").strip()
    if not transcript:
        raise HTTPException(status_code=400, detail="Transcript is empty.")
    try:
        result = _summarize(transcript)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=502,
            detail="The model returned malformed JSON. Please retry.",
        ) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"Summarization failed: {exc}") from exc
    return SummaryResult(transcript=transcript, **result)


@app.post("/api/summarize", response_model=SummaryResult)
async def summarize(file: UploadFile = File(...)) -> SummaryResult:
    if client is None:
        raise HTTPException(
            status_code=500,
            detail="Server is missing OPENAI_API_KEY. Set it in backend/.env.",
        )

    contents = await file.read()
    _validate_upload(file, len(contents))

    suffix = os.path.splitext(file.filename or "")[1].lower()
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(contents)
            tmp_path = tmp.name

        try:
            transcript = _transcribe(tmp_path)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(
                status_code=502, detail=f"Transcription failed: {exc}"
            ) from exc

        if not transcript:
            raise HTTPException(
                status_code=422,
                detail="No speech could be transcribed from this audio.",
            )

        try:
            result = _summarize(transcript)
        except json.JSONDecodeError as exc:
            raise HTTPException(
                status_code=502,
                detail="The model returned malformed JSON. Please retry.",
            ) from exc
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(
                status_code=502, detail=f"Summarization failed: {exc}"
            ) from exc

        return SummaryResult(transcript=transcript, **result)

    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
    )
